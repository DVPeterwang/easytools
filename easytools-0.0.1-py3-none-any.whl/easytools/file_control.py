def r(file):
    f = open(file,'r')
    content = f.read()
    f.close()
    return content
def w(file,write_content):
    f = open(file,'w')
    f.write(write_content)
    f.close()
def a(file, append_content):
    f = open(file,'a')
    f.write(append_content)
    f.close()