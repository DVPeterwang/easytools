import json
def s(content):
    return str(content)
def i(content):
    return int(content)
def f(content):
    return float(content)
def s_to_l(content):
    f_l = []
    for i in content:
        f_l.append(i)
    return f_l
def s_to_d(content):
    f_d = {}
    return json.loads(content)